package com.example.btchess

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import com.github.bhlangonijr.chesslib.*
import com.github.bhlangonijr.chesslib.move.Move

fun Move.uci(): String {
    val p = when (promotion.pieceType) {
        PieceType.QUEEN -> "q"; PieceType.ROOK -> "r"
        PieceType.BISHOP -> "b"; PieceType.KNIGHT -> "n"; else -> ""
    }
    return (from.value() + to.value()).lowercase() + p
}

class GameVM(app: Application) : AndroidViewModel(app) {
    var board = Board(); private set
    var tick by mutableIntStateOf(0); private set          // обновление UI после хода
    var conn by mutableStateOf(Conn.IDLE); private set
    var status by mutableStateOf("")
    var myColor by mutableStateOf<Side?>(null); private set
    var selected by mutableStateOf<Square?>(null); private set
    var lastMove by mutableStateOf<Move?>(null); private set
    var result by mutableStateOf<String?>(null); private set
    var drawOffered by mutableStateOf(false); private set
    var isHost by mutableStateOf(false); private set

    private val bt = BtManager(
        scope = androidx.lifecycle.viewModelScope,
        onLine = ::onLine,
        onState = { c, msg ->
            conn = c; status = msg
            if (c == Conn.CONNECTED && isHost) newGameAsHost()
            if (c == Conn.IDLE) { myColor = null }
        }
    )

    val btEnabled get() = bt.enabled
    fun paired(): List<BluetoothDevice> = bt.pairedDevices()
    fun host() { isHost = true; bt.host() }
    fun join(d: BluetoothDevice) { isHost = false; bt.connect(d) }
    fun leave() { bt.stop(); conn = Conn.IDLE; myColor = null; status = "" }

    // ---- новая партия: хост случайно раздаёт цвета ----
    fun newGameAsHost() {
        val clientWhite = (0..1).random() == 0
        bt.send("START " + if (clientWhite) "W" else "B")
        reset(if (clientWhite) Side.BLACK else Side.WHITE)
    }

    private fun reset(mine: Side) {
        board = Board(); myColor = mine; selected = null; lastMove = null
        result = null; drawOffered = false; tick++
    }

    // ---- ввод игрока ----
    fun tap(sq: Square) {
        val me = myColor ?: return
        if (result != null || board.sideToMove != me) return
        val sel = selected
        val own = board.getPiece(sq).let { it != Piece.NONE && it.pieceSide == me }
        if (sel == null) { if (own) selected = sq; return }
        if (sq == sel) { selected = null; return }
        if (own) { selected = sq; return }
        val moves = board.legalMoves().filter { it.from == sel && it.to == sq }
        val mv = moves.firstOrNull { it.promotion == Piece.NONE || it.promotion.pieceType == PieceType.QUEEN }
        selected = null
        if (mv != null) { apply(mv); bt.send("M " + mv.uci()) }
    }

    fun legalTargets(): Set<Square> {
        val s = selected ?: return emptySet()
        return board.legalMoves().filter { it.from == s }.map { it.to }.toSet()
    }

    private fun apply(m: Move) {
        board.doMove(m); lastMove = m; drawOffered = false; tick++
        when {
            board.isMated -> result = if (board.sideToMove == myColor) "Мат. Вы проиграли" else "Мат! Вы победили"
            board.isStaleMate || board.isDraw -> result = "Ничья"
        }
    }

    fun resign() { if (result == null) { bt.send("RESIGN"); result = "Вы сдались" } }
    fun offerDraw() { if (result == null) { bt.send("DRAW"); status = "Предложение ничьей отправлено" } }
    fun answerDraw(ok: Boolean) {
        bt.send(if (ok) "DRAWOK" else "DRAWNO"); drawOffered = false
        if (ok) result = "Ничья по соглашению"
    }

    // ---- входящие сообщения ----
    private fun onLine(line: String) {
        val cmd = line.substringBefore(' ')
        val arg = line.substringAfter(' ', "")
        when (cmd) {
            "START" -> reset(if (arg == "W") Side.WHITE else Side.BLACK)
            "M" -> {
                val mv = board.legalMoves().firstOrNull { it.uci() == arg.trim().lowercase() }
                if (mv != null && result == null) apply(mv) else bt.send("SYNC")
            }
            "RESIGN" -> result = "Соперник сдался. Вы победили!"
            "DRAW" -> drawOffered = true
            "DRAWOK" -> result = "Ничья по соглашению"
            "DRAWNO" -> status = "Соперник отклонил ничью"
            "SYNC" -> status = "Рассинхронизация, начните новую партию"
        }
    }

    override fun onCleared() { bt.stop() }
}
