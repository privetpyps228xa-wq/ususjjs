package com.example.btchess

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import android.os.Bundle
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.*

class MainActivity : ComponentActivity() {
    private val vm: GameVM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    if (vm.conn == Conn.CONNECTED && vm.myColor != null) GameScreen(vm) else Lobby(vm)
                }
            }
        }
    }
}

@Composable
fun Lobby(vm: GameVM) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(Build.VERSION.SDK_INT < 31) }
    var pendingHost by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = it.values.all { v -> v }
        if (granted && pendingHost) vm.host()
        pendingHost = false
    }
    fun ensure(then: () -> Unit) {
        if (granted) then() else perm.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
    }
    var devices by remember { mutableStateOf(emptyList<android.bluetooth.BluetoothDevice>()) }
    @Suppress("MissingPermission")
    fun refresh() { if (granted) devices = vm.paired() }
    LaunchedEffect(granted) { refresh() }

    Column(Modifier.fillMaxSize().padding(20.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("♞ Bluetooth Шахматы", fontSize = 28.sp)
        Text("Игра без интернета. Сначала свяжите телефоны в настройках Bluetooth.", color = Color.Gray)
        if (vm.status.isNotEmpty()) Text(vm.status, color = MaterialTheme.colorScheme.primary)
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text("Настройки Bluetooth (спарить)")
        }
        Button({
            if (!vm.btEnabled && granted) vm.status = "Включите Bluetooth"
            else if (granted) vm.host() else { pendingHost = true; perm.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT)) }
        }, Modifier.fillMaxWidth()) {
            Text(if (vm.conn == Conn.WAITING) "Ждём соперника… (нажмите для перезапуска)" else "Создать игру (я хост)")
        }
        Text("Или подключитесь к хосту:", fontSize = 16.sp)
        TextButton({ ensure { refresh() } }) { Text("Обновить список") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices) { d ->
                @Suppress("MissingPermission")
                val name = d.name ?: d.address
                Card(Modifier.fillMaxWidth().clickable { vm.join(d) }) {
                    Text(name, Modifier.padding(16.dp), fontSize = 18.sp)
                }
            }
        }
    }
}

private fun glyph(p: Piece) = when (p.pieceType) {
    PieceType.PAWN -> "♟"; PieceType.KNIGHT -> "♞"; PieceType.BISHOP -> "♝"
    PieceType.ROOK -> "♜"; PieceType.QUEEN -> "♛"; PieceType.KING -> "♚"; else -> ""
}

@Composable
fun GameScreen(vm: GameVM) {
    val me = vm.myColor!!
    vm.tick // подписка на изменения доски
    val targets = vm.legalTargets()
    val turnMine = vm.board.sideToMove == me
    val title = vm.result ?: when {
        vm.board.isKingAttacked && turnMine -> "Вам шах! Ваш ход"
        turnMine -> "Ваш ход"
        else -> "Ход соперника…"
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Вы играете за " + if (me == Side.WHITE) "белых" else "чёрных", color = Color.Gray)
        Text(title, fontSize = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))

        BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val cell = maxWidth / 8
            Column {
                for (r in 0 until 8) Row {
                    for (c in 0 until 8) {
                        val rank = if (me == Side.WHITE) 7 - r else r
                        val file = if (me == Side.WHITE) c else 7 - c
                        val sq = Square.encode(Rank.allRanks[rank], File.allFiles[file])
                        val piece = vm.board.getPiece(sq)
                        val dark = (rank + file) % 2 == 0
                        val last = vm.lastMove?.let { it.from == sq || it.to == sq } == true
                        val bg = when {
                            sq == vm.selected -> Color(0xFFF6F669)
                            last -> if (dark) Color(0xFFB9A94A) else Color(0xFFD9CC73)
                            dark -> Color(0xFF769656) else -> Color(0xFFEEEED2)
                        }
                        Box(
                            Modifier.size(cell).background(bg).clickable { vm.tap(sq) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (piece != Piece.NONE) Text(
                                glyph(piece), fontSize = (cell.value * 0.78f).sp,
                                color = if (piece.pieceSide == Side.WHITE) Color.White else Color(0xFF111111),
                                style = TextStyle(shadow = if (piece.pieceSide == Side.WHITE) Shadow(Color.Black, blurRadius = 6f) else null)
                            )
                            if (sq in targets) Box(
                                Modifier.size(cell * if (piece == Piece.NONE) 0.3f else 0.9f).clip(androidx.compose.foundation.shape.CircleShape)
                                    .then(if (piece == Piece.NONE) Modifier.background(Color(0x66000000))
                                          else Modifier.border(3.dp, Color(0x99000000), androidx.compose.foundation.shape.CircleShape))
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        if (vm.status.isNotEmpty()) Text(vm.status, color = Color.Gray)
        if (vm.drawOffered && vm.result == null) {
            Text("Соперник предлагает ничью", fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.answerDraw(true) }) { Text("Принять") }
                OutlinedButton({ vm.answerDraw(false) }) { Text("Отклонить") }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.result == null) {
                OutlinedButton({ vm.resign() }) { Text("Сдаться") }
                OutlinedButton({ vm.offerDraw() }) { Text("Ничья") }
            } else if (vm.isHost) {
                Button({ vm.newGameAsHost() }) { Text("Новая партия") }
            } else Text("Ждём новую партию от хоста…", color = Color.Gray)
            OutlinedButton({ vm.leave() }) { Text("Выйти") }
        }
    }
}
