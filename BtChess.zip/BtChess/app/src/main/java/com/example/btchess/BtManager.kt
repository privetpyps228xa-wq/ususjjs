package com.example.btchess

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.UUID

enum class Conn { IDLE, WAITING, CONNECTING, CONNECTED }

/** Bluetooth Classic RFCOMM. Протокол: одна строка = одно сообщение. Ходы шлются через очередь без задержек. */
@SuppressLint("MissingPermission")
class BtManager(
    private val scope: CoroutineScope,           // Main scope (viewModelScope)
    private val onLine: (String) -> Unit,
    private val onState: (Conn, String) -> Unit
) {
    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val uuid: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
    private var job: Job? = null
    private var socket: BluetoothSocket? = null
    private var outbox = Channel<String>(Channel.UNLIMITED)

    val enabled get() = adapter?.isEnabled == true
    fun pairedDevices(): List<BluetoothDevice> = adapter?.bondedDevices?.toList().orEmpty()

    fun host() {
        stop()
        onState(Conn.WAITING, "Ждём соперника…")
        job = scope.launch(Dispatchers.IO) {
            try {
                val server = adapter!!.listenUsingRfcommWithServiceRecord("BtChess", uuid)
                val s = try { server.accept() } finally { server.close() }
                session(s)
            } catch (e: Exception) { fail(e) }
        }
    }

    fun connect(device: BluetoothDevice) {
        stop()
        onState(Conn.CONNECTING, "Подключаемся к ${device.name}…")
        job = scope.launch(Dispatchers.IO) {
            try {
                adapter?.cancelDiscovery()   // иначе соединение тормозит
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                session(s)
            } catch (e: Exception) { fail(e) }
        }
    }

    private suspend fun session(s: BluetoothSocket) = coroutineScope {
        socket = s
        outbox = Channel(Channel.UNLIMITED)
        withContext(Dispatchers.Main) { onState(Conn.CONNECTED, "Соединено") }
        val out = s.outputStream
        val writer = launch(Dispatchers.IO) {
            for (line in outbox) { out.write((line + "\n").toByteArray()); out.flush() }
        }
        try {
            val reader = s.inputStream.bufferedReader()
            while (isActive) {
                val line = reader.readLine() ?: break
                withContext(Dispatchers.Main) { onLine(line) }
            }
        } finally {
            writer.cancel()
            runCatching { s.close() }
            withContext(NonCancellable + Dispatchers.Main) { onState(Conn.IDLE, "Соединение потеряно") }
        }
    }

    fun send(line: String) { outbox.trySend(line) }

    private suspend fun fail(e: Exception) {
        if (e is CancellationException) return
        withContext(Dispatchers.Main) { onState(Conn.IDLE, "Ошибка: ${e.message ?: "не удалось подключиться"}") }
    }

    fun stop() {
        job?.cancel(); job = null
        runCatching { socket?.close() }; socket = null
    }
}
